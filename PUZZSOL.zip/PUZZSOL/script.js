import DragDrop from './dragDrop.js';

new DragDrop()